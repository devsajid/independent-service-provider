import React from 'react'

function Footer() {
  return (
    <div>
        <p>All rights reserved</p>
    </div>
  )
}

export default Footer