import React from 'react'

function About() {
  return (
    <div>
      <div>
        <h1>Hi, I Am Sohag Hasan</h1>
        <h2>Front End developer</h2>
      </div>
    </div>
  )
}

export default About